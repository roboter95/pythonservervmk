#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from http.server import BaseHTTPRequestHandler,HTTPServer, CGIHTTPRequestHandler



server_address = ("localhost", 4443)
httpd = HTTPServer(server_address, CGIHTTPRequestHandler)
httpd.serve_forever()