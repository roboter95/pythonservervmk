#!/usr/bin/env python3

import random
import time
import sqlite3

class MyServer:
	


	def get_user(self, cookie):
		CON = sqlite3.connect("Cookie.db")
		cur = CON.cursor()
		cur.execute("SELECT * FROM Cookies WHERE Cookie=?", (cookie,))

		rows = cur.fetchall()

		if(len(rows) != 1):
			print ("Too many cookies")
			return

		return rows[0][1]

	def get_gid(self, cookie):
		CON = sqlite3.connect("Cookie.db")
		cur = CON.cursor()
		cur.execute("SELECT * FROM Cookies WHERE Cookie=?", (cookie,))

		rows = cur.fetchall()
		return rows[0][2]

	def get_currentfolder(self, cookie):
		CON = sqlite3.connect("Cookie.db")
		cur = CON.cursor()
		cur.execute("SELECT * FROM Cookies WHERE Cookie=?", (cookie,))

		rows = cur.fetchall()
		return rows[0][3]

	def set_cookies(self, uid, gid, homefolder):
		CON = sqlite3.connect("Cookie.db")
		cur = CON.cursor()
		
		cookie = str(time.time())+str(random.randrange(10**14))

		cur.execute("INSERT INTO Cookies VALUES(?,?,?,?)", (cookie, uid, gid, homefolder))
		CON.commit()
		return cookie



