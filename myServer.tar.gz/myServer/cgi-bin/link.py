#!/usr/bin/env python3

import sqlite3 as lite
import sys
import os
import time
import getpass
import hashlib

def createHash():
	hash =  hashlib.sha1()
	hash.update(bytes(str(time.time()), encoding='UTF-8'))

	return hash


con = lite.connect('userInfo.db')

with con:
    
    cur = con.cursor()

    hash = createHash();  
    #cur.execute('CREATE TABLE links(Hash TEXT, Name TEXT, Uid INT, Gid INT, HomeFolder TEXT, CreationTime TEXT)')
    cur.execute('INSERT INTO Users VALUES(?, ?, ?, ?, ?, ?)', (hash.hexdigest(), getpass.getuser(), os.getuid(), os.getgid(), os.path.expanduser('~'), time.strftime('%H:%M:%S', time.gmtime())))
    con.commit()
    print ("localhost:4443/cgi-bin/checklink.py?hash={0}".format(hash.hexdigest()))