#!/usr/bin/env python3

import cgi
import html
import http.cookies
import os
import sys
import sqlite3
import time
import random
from shutil import copyfileobj
from stat import *
from MyServer import MyServer

pattern = """
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>{}</title>
</head>
<body>
{}
  <form enctype="multipart/form-data" method="post" action="/cgi-bin/browse.py">
   <p><input type="file" name="f">
   <input type="submit" value="Отправить"></p>
  </form> 
</body>
</html>
"""





cookie = http.cookies.SimpleCookie(os.environ.get("HTTP_COOKIE"))
session = cookie.get("session")

if session is None:
	print (pattern.format("Expired session", "Please get a new link to continue working"))

cookieValue = cookie["session"].value

serv = MyServer()
uid = serv.get_user(cookieValue)
gid = serv.get_gid(cookieValue)

form = cgi.FieldStorage()

currentFolder = form.getvalue("folder", "")

if currentFolder == "":
	currentFolder = serv.get_currentfolder(cookieValue)

fileitem = form.getvalue("f", "")
if fileitem != "":

	fileitem = form["f"]
	if not (os.path.exists(os.path.join(currentFolder, fileitem.filename)) and os.path.isdir(os.path.join(currentFolder, fileitem.filename))):
		file = open(os.path.join(currentFolder, fileitem.filename), "wb")
		file.write(fileitem.file.read())

stat1 = os.stat(currentFolder)
mode = stat1.st_mode
if S_ISREG(mode):

	
	# HTTP Header
	print ("Content-Type:application/octet-stream; name=\"alks.txt\"\r\n");
	#print ("Content-Disposition: attachment; filename=\"zdsd.html\"\r\n\n");
	sys.stdout.flush()
	# Actual File Content will go here.
	fo = open(currentFolder, "rb")

	copyfileobj(fo, sys.stdout.buffer)

	# Close opend file
	fo.close()
	exit()

con = sqlite3.connect("Cookie.db")
con.row_factory = sqlite3.Row
cur = con.cursor()
cur.execute("UPDATE Cookies SET CurrentFolder=? WHERE Cookie=?", (currentFolder, cookieValue))
con.commit()

files = []
directories = []

listdir = os.listdir(currentFolder) + [".."]

for f in listdir:
	currentPath = os.path.join(currentFolder, f)
	if not (os.path.exists(currentPath)):
		continue

	stat = os.stat(currentPath)
	mode = stat.st_mode
	if (stat.st_uid == uid):
		if mode & S_IRUSR:
			if S_ISREG(mode):
				files.append(f)
			elif S_ISDIR(mode):
				directories.append(f)


	elif (stat.st_gid == gid):
		if mode & S_IRGRP:
			if S_ISREG(mode):
				files.append(f)
			elif S_ISDIR(mode):
				directories.append(f)

	else:
		if mode & S_IROTH:
			if S_ISREG(mode):
				files.append(f)
			elif S_ISDIR(mode):
				directories.append(f)

directoryInsert = "<li><a href=\"browse.py?folder={}\">{}</a></li>"
fileInsert = "<li><a href=\"browse.py?folder={}\">{}</a></li>"

fullInsert = "<ol>" + "\n"

for d in directories:
	fullPath = os.path.join(currentFolder, d)
	fullInsert += directoryInsert.format(fullPath, d) + "\n"

for f in files:
	fullPath = os.path.join(currentFolder, f)
	fullInsert += fileInsert.format(fullPath, f) + "\n"
fullInsert += "</ol>" + "\n"
print(pattern.format(currentFolder, fullInsert))

