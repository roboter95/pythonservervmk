#!/usr/bin/env python3
import cgi
import html
import http.cookies
import os
import sys
import sqlite3
import time
import random
from MyServer import MyServer

expirationTime = 2

pattern = """
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>{}</title>
</head>
<body>
{}
</body>
</html>
"""

redirectPattern = """
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="refresh" content="3; url=http://localhost:4443/cgi-bin/browse.py?folder={}"/>
</head>
<body>
</body>
</html>
"""

con = sqlite3.connect("userInfo.db")

def checkHash(rows):
	


	if(rows == None):
		print(pattern.format("No link found in database", "Your link is invalid, please get a new one"))
		return False

	hoursCur = time.strftime('%H:%M:%S', time.gmtime())[:2]

	hoursOld = rows[0]["CreationTime"][:2]

	if(abs(int(hoursCur) - int(hoursOld)) > expirationTime):
		print (pattern.format("Bad link", "Your link has expired, please get a new one"))
		return False

	return True


form = cgi.FieldStorage()
hash = form.getvalue("hash", "")

con.row_factory = sqlite3.Row
cur = con.cursor()
cur.execute("SELECT * FROM Users WHERE Hash=?", (hash,))

rows = cur.fetchall()

if not checkHash(rows):
	exit()

uid = rows[0]["Uid"]
gid = rows[0]["Gid"]
homefolder = rows[0]["HomeFolder"]

if(uid):
	serv = MyServer()
	cookieValue = serv.set_cookies(uid, gid, homefolder)
	cookie = http.cookies.SimpleCookie()
	cookie['session'] = cookieValue
	cookie['session']['expires'] = 2 * 60 * 60
	print(cookie.output())
	print(redirectPattern.format(rows[0]["HomeFolder"]))


#if(value is not None):
#	print("asdasd")
#	print(value)
#	exit()
	
