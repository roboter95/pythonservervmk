#!/usr/bin/env python3

import sqlite3 as lite

con = lite.connect('userInfo.db')
con2 = lite.connect('Cookie.db')

with con:
	cur = con.cursor()

	cur.executescript("""
		DROP TABLE IF EXISTS Users;
		CREATE TABLE Users(Hash TEXT, Name TEXT, Uid INT, Gid INT, HomeFolder TEXT, CreationTime TEXT);
		""")

with con2:
	cur2 = con2.cursor()

	cur2.executescript("""
		DROP TABLE IF EXISTS Cookies;
		CREATE TABLE Cookies(Cookie TEXT, Uid INT, Gid INT, CurrentFolder TEXT);
		""")